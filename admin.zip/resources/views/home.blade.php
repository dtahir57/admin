@extends('layouts.app')

@section('content')

@endsection

@section('script')
<script src="{{ asset('js/app.js') }}"></script>
@endsection