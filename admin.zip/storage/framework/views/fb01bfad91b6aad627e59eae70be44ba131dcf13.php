<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Cities</h5>
    <a href="<?php echo e(route('city.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('city.index')); ?>">Cities</a></li>
    <li class="breadcrumb-item active" aria-current="page">Edit</li>
  </ol>
</nav>
<div class="card">
  <div class="card-header">Edit City</div>
  <div class="card-body">
    <form action="<?php echo e(route('city.update', $city->id)); ?>" method="POST">
    	<?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="PATCH">
    	<div class="form-group">
    		<label for="cityName">City Name</label>
    		<input type="text" name="city" required class="form-control" placeholder="City Name" value="<?php echo e($city->city); ?>" />
    	</div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>