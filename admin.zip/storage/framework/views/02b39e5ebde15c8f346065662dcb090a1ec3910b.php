<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Event Places</h5>
    <a href="<?php echo e(route('event_place.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('event_place.index')); ?>">Event Places</a></li>
    <li class="breadcrumb-item active" aria-current="page">Create</li>
  </ol>
</nav>
<div class="card">
  <div class="card-header">New Event Place</div>
  <div class="card-body">
    <form action="<?php echo e(route('event_place.store')); ?>" method="POST">
    	<?php echo e(csrf_field()); ?>

    	<div class="form-group">
    		<label for="name">Event Place Name</label>
    		<input type="text" name="name" required class="form-control" placeholder="Event Name" value="<?php echo e(old('name')); ?>" />
    	</div>
      <div class="form-group">
        <label for="EventID">Events</label>
        <select class="form-control" name="event_id" required>
          <option selected disabled>Please Select an Option</option>
          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($event->id); ?>"><?php echo e($event->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>