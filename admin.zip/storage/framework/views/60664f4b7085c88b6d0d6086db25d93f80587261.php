<?php $__env->startSection('layouts.app'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <nav class="col-sm-3 col-md-2 hidden-xs-down bg-faded sidebar">
      <ul class="nav nav-pills flex-column">
        <li class="nav-item">
          <a class="nav-link <?php echo e((Request::is('home') ? 'active' : '')); ?>" href="<?php echo e(route('home')); ?>">Overview <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e((Request::is('admin/company_types') ? 'active' : '')); ?>" href="<?php echo e(route('company_type.index')); ?>">Company Types</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Analytics</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Export</a>
        </li>
      </ul>

      <ul class="nav nav-pills flex-column">
        <li class="nav-item">
          <a class="nav-link" href="#">Nav item</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Nav item again</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">One more nav</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Another nav item</a>
        </li>
      </ul>

      <ul class="nav nav-pills flex-column">
        <li class="nav-item">
          <a class="nav-link" href="#">Nav item again</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">One more nav</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Another nav item</a>
        </li>
      </ul>
    </nav>
    <main class="col-sm-9 offset-sm-3 col-md-10 offset-md-2 pt-3">
      <?php $__env->startSection('admin'); ?>
        <?php echo $__env->yieldSection(); ?>
    </main>
  </div>
</div>

<?php $__env->stopSection(); ?>
