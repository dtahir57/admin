<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Projects</h5>
    <a href="<?php echo e(route('project.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('project.index')); ?>">Projects</a></li>
    <li class="breadcrumb-item active" aria-current="page">Create</li>
  </ol>
</nav>
<div class="card">
  <div class="card-header">New Project</div>
  <div class="card-body">
    <form action="<?php echo e(route('project.store')); ?>" method="POST">
    	<?php echo e(csrf_field()); ?>

    	<div class="form-group">
    		<label for="CompanyName">Company Name</label>
    		<select class="form-control" name="company_name" required>
          <option selected disabled>Please Select an Option</option>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    	</div>
      <div class="form-group">
        <label for="Name">Name</label>
        <input type="text" name="name" required class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Project Name" />
      </div>
      <div class="form-group">
        <label for="Latitude">Latitude</label>
        <input type="text" name="lat" required class="form-control" value="<?php echo e(old('lat')); ?>" placeholder="latitude" />
      </div>
      <div class="form-group">
        <label for="Longitude">Longitude</label>
        <input type="text" name="lng" required class="form-control" value="<?php echo e(old('lng')); ?>" placeholder="Longitude" />
      </div>
      <div class="form-group">
        <label for="description">Description</label>
        <textarea class="form-control" rows="8" name="description" required placeholder="Project Description"><?php echo e(old('description')); ?></textarea>
      </div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>