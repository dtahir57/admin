<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Events</h5>
    <a href="<?php echo e(route('event.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('event.index')); ?>">Events</a></li>
    <li class="breadcrumb-item active" aria-current="page">Edit</li>
  </ol>
</nav>
<div class="card">
  <div class="card-header">Edit Event</div>
  <div class="card-body">
    <form action="<?php echo e(route('event.update', $event->id)); ?>" method="POST">
    	<?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="PATCH">
    	<div class="form-group">
    		<label for="name">Name</label>
    		<input type="text" name="name" required class="form-control" placeholder="Event Name" value="<?php echo e($event->name); ?>" />
    	</div>
      <div class="form-group">
        <label for="DateFrom">Date From</label>
        <input type="date" name="date_f" required class="form-control" placeholder="Date From" value="<?php echo e($event->date_f); ?>" />
      </div>
      <div class="form-group">
        <label for="DateTo">Date To</label>
        <input type="date" name="date_t" required class="form-control" placeholder="Date To" value="<?php echo e($event->date_t); ?>" />
      </div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>