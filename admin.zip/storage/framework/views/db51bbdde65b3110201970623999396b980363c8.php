<style type="text/css">
	.event_places {
		width: 100%;
		min-height: 250px;
		padding: 20px;
		vertical-align: middle;
		text-align: center;
		background: #fff;
	}
	.event_places:hover {
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	}
</style>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Reservations</h5>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Reservations</li>
  </ol>
</nav>
<section>
	<div class="container-fluid">
		<div class="row">
			<?php $__currentLoopData = $event_places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event_place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4">
				<div class="event_places">
					<h5><?php echo e($event_place->name); ?></h5>
					<form action="<?php echo e(route('reservation.update')); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="_method" value="PATCH" />
						<input type="hidden" name="id" value="<?php echo e($event_place->id); ?>">
						<?php if($event_place->reserved == 1): ?>
						<h1 class="text text-success">Reserved</h1>
						<?php else: ?>
						<button type="submit" class="btn btn-success">Reserve</button>
						<?php endif; ?>
						<?php if($event_place->reserved == 1 AND $event_place->user_id == Auth::user()->id): ?>
						<button type="submit" class="btn btn-default">Remove Reservance</button>
						<?php endif; ?>
					</form>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>