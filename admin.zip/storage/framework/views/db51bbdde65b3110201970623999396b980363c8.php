<style type="text/css">
	.event_places {
		width: 100%;
		min-height: 250px;
		padding: 20px;
		vertical-align: middle;
		text-align: center;
		background: #fff;
	}
	.event_places:hover {
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		cursor: move;
	}
</style>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Reservations</h5>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Reservations</li>
  </ol>
</nav>
<section>
	<div class="container-fluid">
		<div class="row">
			<?php $__currentLoopData = $reservable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4">
				<div class="event_places">
					<h5><?php echo e($reservation->name); ?></h5>
					<form action="reservations" method="POST">
						<input type="hidden" name="_method" value="PATCH" />
						<input type="hidden" name="id" value="<?php echo e($reservation->id); ?>">
						<?php if($reservation->reserved): ?>
							<h1 class="text text-success">Reserved</h1>
						<?php else: ?>
							<button type="submit" class="btn btn-success">Reserve</button>
						<?php endif; ?>
						<?php if($reservation->reserved AND $reservation->user_id): ?>
							<button type="submit" class="btn btn-default">Remove Reservance</button>
						<?php endif; ?>
					</form>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<br>
		<hr>
		<?php if(auth::user()->hasRole('Admin')): ?>
			<client-reservation :reservations="<?php echo e($reservable); ?>" :userid=<?php echo e(Auth::user()->id); ?>></client-reservation>
			<reservation :reservations="<?php echo e($notReservable); ?>" :userid=<?php echo e(Auth::user()->id); ?>></reservation>
		<?php endif; ?>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>