<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Roles</h5>
    <a href="<?php echo e(route('role.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('role.index')); ?>">Roles</a></li>
    <li class="breadcrumb-item active" aria-current="page">Edit</li>
  </ol>
</nav>
<div class="card">
  <div class="card-header">New Role</div>
  <div class="card-body">
    <form action="<?php echo e(route('role.update', $role->id)); ?>" method="POST">
      <input type="hidden" name="_method" value="PATCH">
    	<?php echo e(csrf_field()); ?>

    	<div class="form-group">
    		<label for="RoleName">Role Name</label>
    		<input type="text" name="name" required class="form-control" placeholder="Role Name" value="<?php echo e($role->name); ?>" />
    	</div>
      <h4>Permissions given to <?php echo e($role->name); ?></h4>
      <div class="row">
      <?php $__currentLoopData = Spatie\Permission\Models\Permission::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group col-md-3">
            <label>
              <input type="checkbox" name="permissions[]" value="<?php echo e($permission->name); ?>" class="form-control" <?php if($role->hasPermissionTo($permission)): ?> checked <?php endif; ?>>
               <?php echo e($permission->name); ?>

            </label>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>