<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Companies</h5>
    <a href="<?php echo e(route('company.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('company.index')); ?>">Companies</a></li>
    <li class="breadcrumb-item active" aria-current="page">Edit</li>
  </ol>
</nav>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="alert alert-danger"><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="card">
  <div class="card-header">Update Company</div>
  <div class="card-body">
    <form action="<?php echo e(route('company.update', $company->id)); ?>" method="POST">
    	<?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="PATCH">
    	<div class="row">
        <div class="form-group col-md-6">
          <label for="CompanyType">Name</label>
          <input type="text" name="name" required class="form-control" placeholder="Company Name" value="<?php echo e($company->name); ?>" />
        </div>
        <div class="form-group col-md-6">
          <label>Company Type</label>
          <select class="form-control" name="company_type">
            <option selected disabled>Please Select an Option</option>
            <?php $__currentLoopData = $company_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($company_type->id); ?>" <?php if($company_type->id == $company->company_type->id): ?> selected <?php endif; ?>><?php echo e($company_type->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label for="email">Email</label>
          <input type="email" name="email" required class="form-control" placeholder="Email" value="<?php echo e($company->email); ?>" />
        </div>
        <div class="form-group col-md-6">
          <label for="tel">Phone</label>
          <input type="text" name="tel" required class="form-control" placeholder="Phone" value="<?php echo e($company->tel); ?>" />
        </div>
        <div class="form-group col-md-6">
          <input type="checkbox" name="is_active" <?php if($company->is_active == 1): ?> checked <?php endif; ?> />
          <label for="isActive">Is Active</label>
        </div>
      </div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>