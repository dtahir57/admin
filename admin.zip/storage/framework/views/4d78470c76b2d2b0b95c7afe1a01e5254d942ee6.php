<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Project Units</h5>
    <a href="<?php echo e(route('project_unit.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('project_unit.index')); ?>">Project Units</a></li>
    <li class="breadcrumb-item active" aria-current="page">Create</li>
  </ol>
</nav>
<div class="card">
  <div class="card-header">New Project</div>
  <div class="card-body">
    <form action="<?php echo e(route('project_unit.store')); ?>" method="POST">
    	<?php echo e(csrf_field()); ?>

    	<div class="form-group">
    		<label for="ProjectName">Project Name</label>
    		<select class="form-control" name="project_name" required>
          <option selected disabled>Please Select an Option</option>
          <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="form-group">
          <label for="cityName">City</label>
          <select class="form-control" name="city" required>
            <option selected disabled>Please Select an Option</option>
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($city->id); ?>|<?php echo e($city->city); ?>"><?php echo e($city->city); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label for="projectType">Project Type</label>
          <select class="form-control" name="type" required>
            <option selected disabled>Please Select an Option</option>
            <?php $__currentLoopData = $project_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($project_type->id); ?>|<?php echo e($project_type->project_type); ?>"><?php echo e($project_type->project_type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
    	</div>
      <div class="form-group">
        <label for="Name">Name</label>
        <input type="text" name="name" required class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Project Unit Name" />
      </div>
      <div class="form-group">
        <label for="RateCard">Rate Card</label>
        <input type="text" name="rate_card" required class="form-control" value="<?php echo e(old('rate_card')); ?>" placeholder="Rate Card" />
      </div>
      <div class="form-group">
        <label for="Cost">Cost</label>
        <input type="text" name="cost" required class="form-control" value="<?php echo e(old('cost')); ?>" placeholder="Cost" />
      </div>
      <div class="form-group">
        <label for="Downpayment">Down Payment</label>
        <input type="text" name="down_payment" required class="form-control" value="<?php echo e(old('down_payment')); ?>" placeholder="Down Payment" />
      </div>
      <div class="form-group">
        <label for="installment">Installment</label>
        <input type="text" name="installment" required class="form-control" value="<?php echo e(old('installment')); ?>" placeholder="Installment" />
      </div>
      <div class="form-group">
        <label for="YearOfInstallment">Year Of Installment</label>
        <input type="text" name="year_of_installment" required class="form-control" value="<?php echo e(old('year_of_installment')); ?>" placeholder="Year Of Installment" />
      </div>
      <div class="form-group">
        <label for="area">Area</label>
        <input type="text" name="area" required class="form-control" value="<?php echo e(old('area')); ?>" placeholder="Area" />
      </div>
      <div class="form-group">
        <label for="InstallmentMonthly">Installment Monthly</label>
        <input type="text" name="installment_monthly" required class="form-control" value="<?php echo e(old('installment_monthly')); ?>" placeholder="Installment Monthly" />
      </div>
      <div class="form-group">
        <label for="InstallmentQuarterly">Installment Quarterly</label>
        <input type="text" name="installment_quarter" required class="form-control" value="<?php echo e(old('installment_quarter')); ?>" placeholder="Installment Quarter" />
      </div>
      <div class="form-group">
        <label for="Halfyear">Half Year</label>
        <input type="text" name="half_year" required class="form-control" value="<?php echo e(old('half_year')); ?>" placeholder="Half Year" />
      </div>
      <div class="form-group">
        <label for="InstallmentAnnually">Installment Annually</label>
        <input type="text" name="installment_annually" required class="form-control" value="<?php echo e(old('installment_annually')); ?>" placeholder="Installment Annually" />
      </div>
      <div class="form-group">
        <label for="OfferDiscount">Offer Discount</label>
        <input type="text" name="offer_discount" required class="form-control" value="<?php echo e(old('offer_discount')); ?>" placeholder="Offer Discount" />
      </div>
      <div class="form-group">
        <label for="description">Description</label>
        <textarea class="form-control" rows="8" name="description" required placeholder="Project Unit Description"><?php echo e(old('description')); ?></textarea>
      </div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>