<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Project Types</h5>
    <a href="<?php echo e(route('project_type.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('project_type.index')); ?>">Project Types</a></li>
    <li class="breadcrumb-item active" aria-current="page">Edit</li>
  </ol>
</nav>
<div class="card">
  <div class="card-header">Edit Project Type</div>
  <div class="card-body">
    <form action="<?php echo e(route('project_type.update', $project_type->id)); ?>" method="POST">
    	<?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="PATCH">
    	<div class="form-group">
    		<label for="ProjectType">Project Type</label>
    		<input type="text" name="project_type" required class="form-control" placeholder="Project Type" value="<?php echo e($project_type->project_type); ?>" />
    	</div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>