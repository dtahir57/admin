<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">News</h5>
    <a href="<?php echo e(route('news.index')); ?>" class="btn btn-primary float-right">View All</a>
  </div>
</div>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('news.index')); ?>">News</a></li>
    <li class="breadcrumb-item active" aria-current="page">Create</li>
  </ol>
</nav>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="alert alert-danger"><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="card">
  <div class="card-header">Create News</div>
  <div class="card-body">
    <form action="<?php echo e(route('news.store')); ?>" method="POST">
    	<?php echo e(csrf_field()); ?>

    	<div class="form-group">
    		<label for="title">Title</label>
    		<input type="text" name="title" required class="form-control" placeholder="News Title" value="<?php echo e(old('title')); ?>" />
    	</div>
      <div class="form-group">
        <label for="type">News Type</label>
        <select class="form-control" required name="type">
          <option selected disabled>Please Select an Option</option>
          <option value="local">Local</option>
          <option value="international">International</option>
          <option value="developer">Developer</option>
        </select>
      </div>
      <div class="form-group">
        <label for="body">News Body</label>
        <textarea class="form-control" name="body" cols="8" rows="10"><?php echo e(old('body')); ?></textarea>
      </div>
    	<button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>