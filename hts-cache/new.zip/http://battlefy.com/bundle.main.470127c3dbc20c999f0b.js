Redirecting to https://battlefy.com/bundle.main.470127c3dbc20c999f0b.js
